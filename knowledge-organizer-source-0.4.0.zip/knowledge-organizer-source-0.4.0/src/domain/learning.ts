import type { WorkspaceCard, WorkspaceRound, WorkspaceAnswer } from "./workspace.ts";
import { markKey } from "./workspace.ts";
import { AppError } from "./contracts.ts";

const equal = (a: string[], b: string[]) => a.length === b.length && a.every(id => b.includes(id));

/** 首次作答与重答分别统计；未提交的答案不参与客观判分。 */
export function learningRows(card: WorkspaceCard, round: WorkspaceRound) {
  return round.answers.map((answer, index) => {
    const skipped = answer.locked && answer.selected.length === 0;
    const wrong = answer.locked && !skipped && !equal(answer.selected, card.bank.questions[index]!.correctAnswer);
    const pending = answer.learning?.retryAt != null;
    const doubts = answer.marks.filter(m => !answer.resolvedMarks.includes(markKey(m))).length;
    return { index, answer, wrong, skipped, pending, doubts,
      difficult: wrong || answer.learning?.unknown === true || answer.understood === false || doubts > 0,
      questions: Object.values(answer.discussions).flatMap(d => [
        ...d.messages.filter(m => m.role === "user").map(m => m.content),
        ...d.drafts.map(m => m.text), ...(d.draft.trim() ? [d.draft] : []),
      ]),
    };
  });
}

export function scheduleReview(answer: WorkspaceAnswer, step: number, unknown = false, reason?: string) {
  answer.learning ??= { unknown: false, reason: "", retryAt: null, reviews: [] };
  answer.learning.unknown ||= unknown;
  if (reason !== undefined) answer.learning.reason = reason;
  answer.learning.retryAt = step + 3;
}

export function gradeFirst(card: WorkspaceCard, round: WorkspaceRound, index: number) {
  const answer = round.answers[index]!;
  answer.locked = true;
  if (!equal(answer.selected, card.bank.questions[index]!.correctAnswer) || answer.learning?.unknown)
    scheduleReview(answer, round.practiceStep ?? 0);
}

export function dueReview(round: WorkspaceRound, force = false) {
  return round.answers.findIndex(a => a.locked && a.learning?.retryAt != null &&
    (force || a.learning.retryAt <= (round.practiceStep ?? 0)));
}

export function recordReview(card: WorkspaceCard, round: WorkspaceRound, index: number, selected: string[], now: string) {
  const question = card.bank.questions[index]!, answer = round.answers[index]!;
  if (!answer.locked || !answer.learning || !selected.length || new Set(selected).size !== selected.length ||
    selected.some(id => !question.options.some(o => o.id === id)) || (question.type !== "multiple" && selected.length !== 1))
    throw new AppError("INVALID_INPUT", "请先选择本题重答选项");
  const correct = equal(selected, question.correctAnswer);
  answer.learning.reviews.push({ selected: [...selected], correct, at: now });
  answer.learning.retryAt = correct ? null : (round.practiceStep ?? 0) + 3;
  return correct;
}
