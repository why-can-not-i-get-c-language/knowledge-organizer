# 知识梳理器 0.4.1 源码

本包从本机完整工程的正式源码生成，保留依赖锁文件、资源和Android工程，不由GitHub发布分支git archive生成。公开仓库当前只展示APK、源码ZIP、用户README和IMPORT_FOR_AGENT.md。

## 功能

多层分组、题集导入与扫描、逐题/整套反馈、持久化和备份、原文疑问与DeepSeek问答。0.4.1增加实时统计、错题和提问列表、这题我不会及具体疑问、穿插重答。重答和首次成绩独立，不再强制逐题理解自评。

Bank格式v1，Workspace及学习备份v2；新增字段可选，保留旧v1/v2读取，含新字段的数据不支持降级旧APP。

## 开发与构建

需要Node.js及npm。在解压后的根目录运行：

```powershell
npm ci
npm run typecheck
npm run build
```

网页入口src/design/main.ts；build生成dist及离线资源；开发预览可用npm run dev。领域类型与校验在src/domain，存储与设备适配在src/platform，原生宿主在src/native。src/ui/main.ts为旧宿主，不是当前构建入口。

Android正式入口为npm run android:build，使用Tauri 2、Rust、JDK及Android SDK/NDK。现有脚本默认读取%LOCALAPPDATA%/KnowledgeOrganizer/toolchains，可通过脚本ToolRoot指定同结构工具目录。工具链、依赖缓存和签名材料不在源码包中。需要既有android-release.p12和DPAPI保护的android-release.password（位于%LOCALAPPDATA%/KnowledgeOrganizer/signing）；缺失即停止，不生成新签名。其他开发者须使用自己的合法签名流程，不能覆盖原应用。不能将本机DPAPI口令文件直接当成跨电脑可用口令。

本版包名app.knowledgeorganizer.learning、版本码4000、ARM64，最低Android 7；Windows安装包未实现。API Key由用户在应用内配置，源码与普通学习备份不含密钥；AI功能仍需真实设备验证。

IMPORT_FOR_AGENT.md是题集导入规范。不得将个人题集、学习数据、内部文档或凭据混入公开交付包。
0.4.1问答交互：固定顶部返回箭头，点击面板外空白关闭；发送与概括直接请求流式回答，取消强制预览。多次提问显示侧边分段索引，点击跳到对应提问和回答，底部箭头回到输入区。关闭保留草稿和部分回答，取消生成，不新增数据字段。
