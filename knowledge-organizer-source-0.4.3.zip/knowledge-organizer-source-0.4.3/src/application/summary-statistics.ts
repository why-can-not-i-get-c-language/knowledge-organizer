import type { WorkspaceCard, WorkspaceRound, WorkspaceDiscussion } from "../domain/workspace.ts";

/** 分类只依据题集知识点及用户指定的分类，不从答题阶段推测正确答案。 */
export function summaryEntries(card: WorkspaceCard, rounds: WorkspaceRound[]) {
  return rounds.flatMap(round => round.answers.flatMap((answer, index) =>
    Object.values(answer.discussions)
      .filter(d => d.summary && !d.summary.deleted)
      .map(discussion => ({ round, answer, index, discussion, question: card.bank.questions[index]! })),
  ));
}

export function summaryCategory(question: WorkspaceCard["bank"]["questions"][number], discussion: WorkspaceDiscussion) {
  if (discussion.summary?.category) return discussion.summary.category;
  const points = question.knowledgePoints.map(point => point.trim()).filter(Boolean);
  // 同一父知识点的相近分支归在一起；单层知识点保留原名称，模块作为分类边界。
  return [question.module, ...(points.length > 1 ? points.slice(0, -1) : points)]
    .filter((value, at, all) => value && (at === 0 || value !== all[at - 1])).join(" / ") || "未分类";
}

export function groupSummaries(entries: ReturnType<typeof summaryEntries>) {
  const groups = new Map<string, { category: string; entries: typeof entries }>();
  for (const entry of entries) {
    const category = summaryCategory(entry.question, entry.discussion);
    const key = category.normalize("NFKC").toLocaleLowerCase().replace(/\s+/gu, "");
    const group = groups.get(key) ?? { category, entries: [] };
    group.entries.push(entry);
    groups.set(key, group);
  }
  return [...groups.values()].sort((a, b) => b.entries.length - a.entries.length || a.category.localeCompare(b.category, "zh-CN"));
}
