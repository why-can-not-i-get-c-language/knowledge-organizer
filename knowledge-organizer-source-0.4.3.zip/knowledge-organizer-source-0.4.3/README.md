# 知识梳理器 0.4.3 源码

本包从本机完整实际工程生成，包含正式源码、资源、依赖锁文件和 Android 工程，不从仅含四个发布文件的 main 执行 git archive 打包。

本版：局部标记直接打开问答；概括从问答中的“编辑概括”进入，可保存、修改、分类或删除。统计与错题中的概括表汇总当前及历史轮次，支持一键按知识点层级分类统计，人工分类优先。逐题反馈答对自动前进，重答答对继续，整套提交模式不提前判分。保留多层分组、导入扫描、错题与疑问、穿插重答、直接流式问答和会话索引。

Bank v1，Workspace/备份 v2。概括增加可选分类和删除占位，旧数据继续读取，引用快照保留；新记录不能降级旧版读取。

## 构建

需要 Node.js 及 npm；解压到空目录后在根目录执行：

    npm ci
    npm run typecheck
    npm run build

网页入口 src/design/main.ts；npm run dev 可预览，npm run build 生成 dist 和离线资源。领域逻辑在 src/domain，应用逻辑在 src/application，设备适配在 src/platform，原生宿主在 src/native。src/ui/main.ts 为旧宿主，不是当前构建入口。

Android 入口 npm run android:build，使用 Tauri 2、Rust、JDK 与 Android SDK/NDK。脚本默认读取 %LOCALAPPDATA%/KnowledgeOrganizer/toolchains，可通过 ToolRoot 参数指定同结构工具目录。需既有签名 android-release.p12 和 Windows DPAPI 保护的 android-release.password，位于 %LOCALAPPDATA%/KnowledgeOrganizer/signing。脚本缺失既有签名即停止，不重新生成；其他开发者应使用自己的合法签名流程，无法覆盖原应用。DPAPI 文件不能直接跨电脑解密。

包名 app.knowledgeorganizer.learning，4003/0.4.3，Android 7 以上、ARM64。没有 Windows 安装包。工具链、签名材料、API Key、个人题集和学习数据均不在本包内。用户自行在应用内配置 DeepSeek Key。安装、手机触控和真实 API 调用需另行验证。

IMPORT_FOR_AGENT.md 是唯一题集导入技术规范。公开仓库只发布 APK、一个源码 ZIP、用户 README 和导入规范，不上传内部开发文档。
